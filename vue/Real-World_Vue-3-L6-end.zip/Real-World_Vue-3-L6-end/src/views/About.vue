<template>
  <div class="about">
    <p>A site for events to better the world.</p>
  </div>
</template>
